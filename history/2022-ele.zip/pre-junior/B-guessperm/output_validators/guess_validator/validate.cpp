#include "validate.h"
#include <bits/stdc++.h>

using namespace std;

string to_string(const vector<int> &a) {
    const int N = a.size();
    string msg;
    for (int i = 0; i < min(N, 10); i++) {
        if (i != 0)
            msg += ", ";
        msg += to_string(a[i]);
    }
    if (N > 10) {
        msg += ", ...";
    }
    return msg;
}

#define ENSURE(cond, op...) if (not (cond)) { wrong_answer(op); }

void check_case() {
    string line;
    /* Get test mode description from judge input file */
    assert(getline(judge_in, line));

    int N = -1;
    int seed = -1;
    if (sscanf(line.c_str(), "%d %d", &N, &seed) != 2) {
        assert(!"unknown input instructions");
    }
    assert (1 <= N && N <= 500);
    cerr << "N = " << N << endl;
    cerr << "seed = " << seed << endl;

    cout << N << '\n';
    cout.flush();

    vector<int> p(N);
    std::iota(p.begin(), p.end(), 1);

    std::mt19937 rng(seed);
    std::shuffle(p.begin(), p.end(), rng);

    vector<int> revp(N + 1, -1);
    for (int i = 0; i < N; i++)
        revp[p[i]] = i;

    judge_message("I'm thinking of " + to_string(p) + '\n');

    const int max_guess = ceil(N * log2l(N)) + 1;
    for (int guesses = 0; guesses < max_guess; ++guesses) {
        string in;
        ENSURE(getline(team_out, in), "Guess %d: couldn't read a line\n", guesses + 1);

        stringstream ss(in);
        int K;
        ENSURE(ss >> K,
                "Guess %d: couldn't read an integer\n", guesses + 1);
        ENSURE(1 <= K && K <= N,
                "Guess %d: K must satisfy 1 <= K <= N\n", guesses + 1);

        vector<int> a(K);
        for (int j = 0; j < K; j++) {
            ENSURE(ss >> a[j],
                    "Guess %d: couldn't read an integer\n", guesses + 1);
            ENSURE(1 <= a[j] && a[j] <= N,
                    "Guess %d: a[j] must satisfy 1 <= a[j] <= N\n", guesses + 1);
        }
        if (ss >> in) {
            wrong_answer("Guess %d: %s trailing..\n", guesses + 1, in);
        }

        // judge_message("Guess %d is %d\n", guesses + 1, guess);

        if (a == p) {
            cout << "Gotowe\n";
            cout.flush();
            return;
        } else {
            bool is_subseq = true;
            for (int j = 0; j < K; j++) {
                a[j] = revp[a[j]];
                assert (0 <= a[j] && a[j] < N);
            }
            for (int j = 1; j < K; j++) {
                if (a[j - 1] >= a[j]) {
                    is_subseq = false;
                }
            }

            if (is_subseq) {
                cout << "Tak\n";
                cout.flush();
            } else {
                cout << "Nie\n";
                cout.flush();
            }
        }
    }
    wrong_answer("Didn't get to correct answer in %d guesses, N = %d\n", max_guess, N);
    return;
}

int main(int argc, char **argv) {
    cerr << "validator main start" << endl;
    init_io(argc, argv);

    check_case();

    /* Check for trailing output. */
    string trash;
    if (team_out >> trash) {
        wrong_answer("Trailing output\n");
    }

    /* Yay! */
    accept();
}

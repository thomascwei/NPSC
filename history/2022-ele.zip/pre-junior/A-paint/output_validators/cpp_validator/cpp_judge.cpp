#include "testlib_checker.h"
#include <bits/stdc++.h>
using namespace std;
using ll = long long;
#define pb emplace_back
#define AI(i) begin(i), end(i)
template<class T> bool chmin(T &a, T b) { return b < a && (a = b, true); }
template<class T> bool chmax(T &a, T b) { return a < b && (a = b, true); }
#ifdef KEV
#define DE(args...) kout("[ " + string(#args) + " ] = ", args)
void kout() { cerr << endl; }
template<class T, class ...U> void kout(T a, U ...b) { cerr << a << ' ', kout(b...); }
template<class T> void debug(T l, T r) { while (l != r) cerr << *l << " \n"[next(l)==r], ++l; }
#else
#define DE(...) 0
#define debug(...) 0
#endif
// }}}

// ./validator judge_in(input) judge_ans feedback_dir [additional_arguments] < team_out [ > team_input ]

/* For note
 inf: judge_in
 ouf: team_out
 ans: judge_ans
 */

const int MAX_N = 4010, MOD = 1e9 + 7;

// bad, people, exit, magic, dfs
// . P X O -
string g[MAX_N], sol[MAX_N];

int N;


bool valid(char a, char b) {
	return a == b || (a == '.' && b == 'O');
}
void dfs(int i, int j) {
	if (i >= N || j >= N || i < 0 || j < 0) return;
	if (sol[i][j] == '.'
			|| sol[i][j] == '-') return;
	sol[i][j] = '-';
	dfs(i, j-1);
	dfs(i, j+1);
	dfs(i+1, j);
	dfs(i-1, j);
}
	
int main(int argc, char* argv[]) {
    registerTestlibCmd(argc, argv);

    N = inf.readInt(1, 4000);
    for (int i = 0;i < N; ++i)
		g[i] = inf.readToken();

	for (int i = 0;i < N;++i) {
		//sol[i] = ouf.readToken("[.XPO]{" + to_string(N) + "}");
		sol[i] = ouf.readToken();
		if (sol[i].size() != N)
			wrong_answer("map size wrong");
	}
	for (int i = 0;i < N;++i)
		for (int j = 0;j < N;++j)
			if (!valid(g[i][j], sol[i][j]))
				wrong_answer("map item impossible");

	ll cnt = 0, mx_cnt = 1ll * N * N / 2;

	for (int i = 0;i < N;++i) 
		cnt += count(AI(sol[i]), 'O');

	DE(cnt, N, cnt);
	if (cnt > mx_cnt)
		wrong_answer("impossible magics !");

	dfs(0, 0);

	for (int i = 0;i < N;++i)
		for (int j = 0;j < N;++j)
			if (sol[i][j] == 'P')
				wrong_answer("not connected");

    accept();
}
